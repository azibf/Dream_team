#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include "enum_dec.h"
#include "string_func.h"
#include "pack_func.h"

enum Gender get_gender(short info)
{
    short x = ((info & (1 << 15)) >> 15);
    enum Gender gender = x;
    return gender;
}

unsigned short get_age(short info)
{
    short x = ((info & (127 << 8)) >> 8);
    unsigned short age = x;
    return age;
}

enum Education get_education(short info)
{
    short x = ((info & (3 << 6)) >> 6);
    enum Education education = x;
    return education;
}

enum HairColor get_hair_color(short info)
{
    short x = ((info & (3 << 4)) >> 4);
    enum HairColor color = x;
    return color;
}

enum MaritalStatus get_marital_status(short info)
{
    short x = ((info & (1 << 3)) >> 3);
    enum MaritalStatus status = x;
    return status;
}

enum Work get_work(short info)
{
    short x = ((info & (1 << 2)) >> 2);
    enum Work work = x;
    return work;
}

enum Character get_character(short info)
{
    short x = (info & 3);
    enum Character character = x;
    return character;
}

