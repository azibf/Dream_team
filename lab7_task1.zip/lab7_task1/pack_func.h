#ifndef PACK_FUNC_H_INCLUDED
#define PACK_FUNC_H_INCLUDED

void pack_gender(short *info, enum Gender gender);

void pack_age(short *info, short age);

void pack_education(short *info, enum Education education);

void pack_hair_color(short *info, enum  HairColor color);

void pack_marital_status(short *info, enum  MaritalStatus status);

void pack_work(short *info, enum Work work);

void pack_character(short *info, enum Character character);

short pack_info();


#endif // PACK_FUNC_H_INCLUDED
