#ifndef STRING_FUNC_H_INCLUDED
#define STRING_FUNC_H_INCLUDED

const char *gender_to_string(enum Gender gender);

const char *education_to_string(enum Education education);

const char *hair_color_to_string(enum HairColor color);

const char *marital_status_to_string(enum MaritalStatus status);

const char *work_to_string(enum Work work);

const char *character_to_string(enum Character type);

void print_info(short info);


#endif // STRING_FUNC_H_INCLUDED
