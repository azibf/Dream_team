#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include "enum_dec.h"
#include "string_func.h"
#include "pack_func.h"
#include "get_func.h"


int main()
{
    int size = sizeof(short);
    short *mas = NULL;
    int counter = 0;
    mas = (short*) malloc(counter * size);
    int repit = 1;
    printf("Hello!\nI am Big Brother!\nPlease, give me some information about other people :3\n");
    while (repit != 0)
    {
        ++counter;
        mas = realloc(mas, counter * size);
        mas[counter - 1] = pack_info();
        printf("Check size: %d", sizeof(mas[counter - 1]));
        printf("\nDo you want add one more person? 0 - No, other numbers - yes ");
        scanf("%d", &repit);
    }
    for(int i = 0; i < counter; ++i) {printf("\nHUMAN %d \n", (i + 1));print_info(mas[i]);}
}
