#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include "enum_dec.h"
#include "string_func.h"
#include "get_func.h"


void pack_gender(short *info, enum Gender gender)
{
    *info |= (((short)gender) << 15 );
}
void pack_age(short *info, short age)
{
    *info |= (((short)age) << 8);
}
void pack_education(short *info, enum Education education)
{
    *info |= (((short)education) << 6);
}
void pack_hair_color(short *info, enum  HairColor color)
{
    *info |= (((short)color) << 4);
}
void pack_marital_status(short *info, enum  MaritalStatus status)
{
    *info |= (((short)status) << 3);
}

void pack_work(short *info, enum Work work)
{
    *info |= (((short)work) << 2);
}

void pack_character(short *info, enum Character character)
{
    *info |= ((short)character);
}

short pack_info()
{
    short info = 0;
    short age, a;
    enum Gender gender; enum Education education; enum HairColor color;
    enum MaritalStatus status; enum Work work; enum Character character;
    printf("Enter gender 0 - Male, 1 - Female\n");
    scanf("%d", &a);
    gender = a % 2;
    printf("Enter age from 0  to 120\n");
    scanf("%d", &age);
    age = age % 121;
    printf("Enter education 0 - no education, 1 - unfinished secondary education, 2 - secondary education, 3 - high education\n");
    scanf("%d", &a);
    education = a % 4;
    printf("Enter hair color 0 - bold, 1 - fair, 2 - dark, 3 - red\n");
    scanf("%d", &a);
    color = a % 4;
    printf("Enter marital status 0 - free, 1 - married\n");
    scanf("%d", &a);
    status = a % 2;
    printf("Enter work status 0 - unemployed, 1 - employed\n");
    scanf("%d", &a);
    work = a % 2;
    printf("Enter character 0 - Nordic, 1 - Melancholic, 2 - Choleric\n");
    scanf("%d", &a);
    character = a % 3;
    short *p_info;
    p_info = &info;
    pack_gender(p_info, gender);
    pack_age(p_info, age);
    pack_education(p_info, education);
    pack_hair_color(p_info, color);
    pack_marital_status(p_info, status);
    pack_work(p_info, work);
    pack_character(p_info, character);
    return info;
}
