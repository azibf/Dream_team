#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>

enum Gender {
    MALE,
    FEMALE
};

enum Education {
    NO,
    UNFINSEC,
    SECONDARY,
    HIGH
};

enum HairColor {
    BOLD,
    BLACK,
    WHITE,
    RED
};

enum MaritalStatus {
    FREE,
    MARRIED
};

enum Work {
    UNEMPLOYED,
    EMPLOYED
};

enum Character {
    NORDIC,
    MELANCHOLIC,
    CHOLERIC
};
