#ifndef GET_FUNC_H_INCLUDED
#define GET_FUNC_H_INCLUDED

enum Gender get_gender(short info);

unsigned short get_age(short info);

enum Education get_education(short info);

enum HairColor get_hair_color(short info);

enum MaritalStatus get_marital_status(short info);

enum Work get_work(short info);

enum Character get_character(short info);


#endif // GET_FUNC_H_INCLUDED
