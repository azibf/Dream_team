#ifndef ENUM_DEC_H_INCLUDED
#define ENUM_DEC_H_INCLUDED

enum Gender {
    MALE,
    FEMALE
};

enum Education {
    NO,
    UNFINSEC,
    SECONDARY,
    HIGH
};

enum HairColor {
    BOLD,
    BLACK,
    WHITE,
    RED
};

enum MaritalStatus {
    FREE,
    MARRIED
};

enum Work {
    UNEMPLOYED,
    EMPLOYED
};

enum Character {
    NORDIC,
    MELANCHOLIC,
    CHOLERIC
};


#endif // ENUM_DEC_H_INCLUDED
