#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include "enum_dec.h"
#include "pack_func.h"
#include "get_func.h"


const char *gender_to_string(enum Gender gender)
{
    switch(gender)
    {
        case(MALE): return "Male";
        case(FEMALE): return "Female";
        default: return "combat helicopter";
    }
}

const char *education_to_string(enum Education education)
{
    switch(education)
    {
        case(NO): return "No education";
        case(UNFINSEC): return "Unfinished secondary education";
        case(SECONDARY): return "Secondary education";
        case(HIGH): return "High education";
        default: return "Sverhrazum";
    }

}

const char *hair_color_to_string(enum HairColor color)
{
    switch(color)
    {
        case(BOLD): return "Bold";
        case(WHITE): return "Fair hair";
        case(BLACK): return "Dark hair";
        case(RED): return "Red hair";
        default: return "Colorful";
    }
}

const char *marital_status_to_string(enum MaritalStatus status)
{
    switch(status)
    {
        case(FREE): return "Free";
        case(MARRIED): return "Married";
        default: return "Polyamory";
    }
}

const char *work_to_string(enum Work work)
{
    switch(work)
    {
        case(UNEMPLOYED): return "Has not work";
        case(EMPLOYED): return "Has work";
        default: return "Secret infromation";
    }
}

const char *character_to_string(enum Character type)
{
    switch(type)
    {
        case(NORDIC): return "Nordic";
        case(MELANCHOLIC): return "Melancholic";
        case(CHOLERIC): return "Choleric";
        default: return "Character as character";
    }
}

void print_info(short info)
{
    printf("Gender: %s \n", gender_to_string(get_gender(info)));
    printf("Age: %d \n", get_age(info));
    printf("Education: %s \n", education_to_string(get_education(info)));
    printf("Hair Color: %s \n", hair_color_to_string(get_hair_color(info)));
    printf("Martial status: %s \n", marital_status_to_string(get_marital_status(info)));
    printf("Work: %s \n", work_to_string(get_work(info)));
    printf("Character: %s \n", character_to_string(get_character(info)));
}
